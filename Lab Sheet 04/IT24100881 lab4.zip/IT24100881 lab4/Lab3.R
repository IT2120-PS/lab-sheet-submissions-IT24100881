setwd("C:/Users/IT24100881/Desktop/IT24100881 lab4")

branch_data<-read.csv("Exercise.txt", header = TRUE)
print(branch_data)


#Q2

print("Variable types and scale:\n")
print("Branch-> Categorical(Nominal)\n")
print("Sales_X1->Numeric(Ratio)\n")
print("Advertising_x2=Numeric(Ratio)\n")
print("Years_X3->Numeric(Ratio)\n")




#Q3

print("Variable types and scales:\n")
print("Branch->Categorical(Nominal)\n")
print("Sales_x1-> Numeric(Ratio)\n")
print("Advertising_X2 Numeric(Ratio)\n")
print("Years_X3-> Numeric(Ratio)\n")


print("   ")
boxplot(branch_data$Sales_X1,
        main = "Boxplot of sales",
        ylab = "Sales",
        col = "pink")



print("Five number Summary for Advertising:\n ")

print(summary(branch_data$Advertising_X2))

print("IQR advertising")

print(IQR(branch_data$Advertising_X2))


find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
